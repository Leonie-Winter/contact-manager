import subprocess
import sys
import importlib

# List of required packages
# Note: "via importlib" : "via pip"
required_packages = {
    #"PIL": "Pillow",
    "customtkinter": "customtkinter",
}

def install_and_import(module_name, package_name):
    try:
        importlib.import_module(module_name)
        print(f"[OK] {module_name} is already installed.")
    except ImportError:
        print(f"[INFO] {module_name} not found. Installing {package_name}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"[INFO] {package_name} installed.")

# Install all required packages
for module, package in required_packages.items():
    install_and_import(module, package)

# Run gui.py
subprocess.run([sys.executable, "gui/gui.py"])
