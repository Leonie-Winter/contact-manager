# Notes for the developers

- to start application run main.py
- Note: it auto installs packages, add more if needed

## Dokumentations

- CustomTkinter: https://customtkinter.tomschimansky.com/